<a name="搭配_Spring_Boot"></a>
# 搭配 Spring Boot

请查看 [MyBatis Spring-boot-starter](http://www.mybatis.org/spring-boot-starter/mybatis-spring-boot-autoconfigure) 子项目获取更多信息。
