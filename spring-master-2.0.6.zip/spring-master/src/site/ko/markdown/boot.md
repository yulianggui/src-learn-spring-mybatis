<a name="스프링_부트_사용하기"></a>
# 스프링 부트 사용하기

자세한 내용은 [MyBatis Spring-boot-starter](http://www.mybatis.org/spring-boot-starter/mybatis-spring-boot-autoconfigure) 하위 프로젝트 문서를 참조하십시오.
